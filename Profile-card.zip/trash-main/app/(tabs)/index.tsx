import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';

export default function ProfileCardScreen() {
  return (
    <View style={styles.pageBackground}>
      {/* Profile Card */}
      <View style={styles.profileCard}>

        {/* Profile Image (Rounded Square) */}
        <Image
          source={require('../../assets/images/profile.jpg')}
          style={styles.avatar}
        />

        {/* Name and Role */}
        <Text style={styles.userName}>Ali Kasbati</Text>
        <Text style={styles.userRole}>Software Developer</Text>

        {/* Buttons (Flexbox Layout applied here) */}
        <View style={styles.buttonWrapper}>
          <TouchableOpacity style={[styles.actionBtn, styles.followBtn]}>
            <Text style={styles.followText}>Follow</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.actionBtn, styles.messageBtn]}>
            <Text style={styles.messageText}>Message</Text>
          </TouchableOpacity>
        </View>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  // Pastel color background
  pageBackground: {
    flex: 1,
    backgroundColor: '#E0FBFC', // Soft light cyan
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileCard: {
    backgroundColor: '#FFFFFF',
    width: 340,
    paddingVertical: 40,
    paddingHorizontal: 30,
    borderRadius: 24, // Softer, larger rounded corners on the card
    alignItems: 'center',
    // Soft, diffused shadow
    elevation: 5,
    shadowColor: '#293241',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.08,
    shadowRadius: 15,
  },
  avatar: {
    width: 105,
    height: 105,
    borderRadius: 25, // Creates a rounded square instead of a circle
    marginBottom: 20,
  },
  userName: {
    fontSize: 26,
    fontWeight: '900',
    color: '#293241', // Dark navy blue
    marginBottom: 6,
  },
  userRole: {
    fontSize: 13,
    fontWeight: '700',
    color: '#3D5A80',
    letterSpacing: 1.5, // Spaced out uppercase text
    marginBottom: 35,
  },
  // Assignment Requirement: Flexbox row & space-between
  buttonWrapper: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    width: '100%',
  },
  actionBtn: {
    paddingVertical: 14,
    borderRadius: 8, // Sharper, slight rounding for a techy feel
    width: '46%',
    alignItems: 'center',
  },
  followBtn: {
    backgroundColor: '#EE6C4D', // Bold Coral/Orange color
  },
  followText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
  },
  messageBtn: {
    backgroundColor: 'transparent',
    borderWidth: 2,
    borderColor: '#EE6C4D',
  },
  messageText: {
    color: '#EE6C4D',
    fontWeight: '800',
    fontSize: 16,
  },
});